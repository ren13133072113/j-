﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2_8_Git及计算器重构
{
    class calculator
    {
        int a;
        public int A
        {
            get { return a; }
            set { a = value; }
        }
        int b;
        public int B
        {
            get { return b; }
            set { b = value; }
        }
        public void input()
        {
            Console.WriteLine("请选择输入字符串或整数，字符串选择s,整数选择i");
            string x = Console.ReadLine();
            if (x == "s")
            {
                Console.WriteLine("请输入第一个字符串");
                string aa = Console.ReadLine();
                Console.WriteLine("请输入第二个字符串");
                string bb = Console.ReadLine();
                Console.WriteLine("请输入\"+\",\"-\"中的任意一种运算符");
                string cc = Console.ReadLine();
                Equals(aa, bb);
                switch (cc)
                {
                    case ("+"):
                        add_1(aa, bb);
                        break;
                    case ("-"):
                        reduce_1(aa, bb);
                        break;
                    default:
                        Console.WriteLine("输入有误，请重新输入");
                        break;
                }
            }
            else if (x == "i")
            {
                Console.WriteLine("请输入一个整数");
                a = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("请输入另一个整数");
                b = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("请输入\"+\",\"-\",\"*\",\"/\"任意一种运算符");
                string c = Console.ReadLine();
                Equals();
                switch (c)
                {
                    case "+":
                        add();
                        break;
                    case "-":
                        reduce(); break;
                    case "*":
                        multiply(); break;
                    case "/":
                        devise(); break;
                    default:
                        Console.WriteLine("您输入的运算符有误！！");
                        break;
                }
            }
            else
                Console.WriteLine("输入有误，请重新输入");
        }
        public void add_1(string s1, string s2)
        {
            string _sum = s1 + s2;
            Console.WriteLine("进行加法的连接结果为" + _sum);
        }
        public void reduce_1(string s1, string s2)
        {
            bool h = s1.Contains(s2);
            string s3;
            if (h)
            {
                int i = s1.IndexOf(s2);
                s3 = s1.Remove(i, s2.Length);
                if (!s3.Contains(s2))
                {
                    Console.WriteLine("进行减法运算的结果" + s3.ToString());
                }
            }
            else
            {
                Console.WriteLine("无法进行减法");
            }
        }
        public void Equals(string s1, string s2)
        {
            if (s1.CompareTo(s2) == 0)
            {
                Console.WriteLine("输入的两个字符串相等");
            }
            else
                Console.WriteLine("输入的两个字符串不相等");
        }
        public void add()
        {
            int sum = a + b;
            Console.WriteLine("进行加法运算的结果为" + sum);
        }
        public void reduce()
        {
            int d = a - b;
            Console.WriteLine("进行减法运算的结果为" + d);
        }
        public void multiply()
        {
            int d1 = a * b;
            Console.WriteLine("进行乘法运算的结果为" + d1);
        }
        public void devise()
        {
            double d2 = (double)a / b;
            Console.WriteLine("进行除法运算的结果为" + d2);
        }
        public void Equals()
        {
            if (a == b)
            {
                Console.WriteLine("输入的两个数相等");
            }
            else
            {
                Console.WriteLine("输入的两个数不相等");
            }

        }
    }
}

