﻿using System;
namespace _2_8_Git及计算器重构
{
    class Program
    {
        static void Main(string[] args)
        {
            calculator ca = new calculator();
            ca.input();
        }
    }
}
